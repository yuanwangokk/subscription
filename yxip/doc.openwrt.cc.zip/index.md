# 简介

## 适用范围

本站点文档适用于以下仓库:

!!! info ""
    * [OpenWrt-Rpi](/2-OpenWrt-Rpi): 预置丰富插件的 OpenWrt 固件
    * [OpenWrt-BuildBot](/3-OpenWrt-Buildbot): 纯净、具有高度客制化特性的 OpenWrt 固件
    * [OpenWrt-Docker](/4-OpenWrt-Docker): 具有高度客制化特性的 OpenWrt Docker 镜像

## 特色

!!! tip ""
    * 固件 / 镜像基于 Github Action 编译， Workflows 完全开源
    * 支持绝大多数 “源码支持” 的 arm/aarch64/x86 平台设备
    * 提供与固件 / 镜像完全兼容的自建软件源，可随意安装 7000+ 软件包
    * 固件 / 镜像跟随源码更新自动编译，确保获得最新体验
    * 提供全格式固件 / 文件 (ext4/squashfs/ubi/initramfs/rootfs)
    * 提供完整的固件 / 软件包构建工具 (imagebuilder/sdk/toolchain)
    * 拒绝非必要魔改，回归本真









