# 适用范围

General 目录下提供的文档共同适用于本站点介绍的某些项目，

你可以在下方表格或左侧侧栏 General 分组下找到它们。

以下为 General 目录下各文档的适用范围:

| 文档名称<img width=125/>                   | 适用项目                                          |
| ------------------------------------------ | ------------------------------------------------- |
| [安装 / 升级](/1-General/1-Install-Upgrade)  | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [初始设置](/1-General/2-Initialization)      | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [文件名索引](/1-General/3-File-Name)         | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [文件格式手册](/1-General/4-Firmware-Format) | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [IPV6 指南](/1-General/5-IPV6-Guide)         | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [空间扩容指南](/1-General/6-Resize)          | `OpenWrt-Rpi` `OpenWrt-Buildbot`                  |
| [软件包安装指南](/1-General/7-Packages)      | `OpenWrt-Rpi` `OpenWrt-Buildbot` `OpenWrt-Docker` |

