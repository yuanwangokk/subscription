# 安装/升级

!!! tip ""
    本文档适用范围：[OpenWrt-Rpi](/2-OpenWrt-Rpi)、[OpenWrt-Buildbot](/3-OpenWrt-Buildbot)

## 安装

### 以 SD 卡为存储介质的设备

(本节适用于树莓派全系列/NanoPi 等以 SD 卡为存储介质的设备)

请务必按照以下步骤操作:

!!! info ""
    1. 从 [软件源站](https://openwrt.cc/restore) 下载 「[存储还原固件](https://openwrt.cc/restore/Restore-SD-Card-2G.zip)」至电脑；
    2. 将 SD 卡插入电脑，使用 [Win32 Disk Imager](https://sourceforge.net/projects/win32diskimager/) 或者 [Etcher](https://www.balena.io/etcher/) 将「[存储还原固件](https://openwrt.cc/restore/Restore-SD-Card-2G.zip)」 写入 SD 卡；
    3. 从 [软件源站](https://openwrt.cc) 下载 OpenWrt 固件；
    4. 无需弹出 SD 卡，使用 [Win32 Disk Imager](https://sourceforge.net/projects/win32diskimager/) 或者 [Etcher](https://www.balena.io/etcher/) 将 OpenWrt 固件刷入 SD 卡即可。

### 路由器设备

(以 OpBoot 支持的路由器设备为例)

!!! info ""
    1. 推荐将设备升级为最新版 OpBoot；
    2. 从 [软件源站](https://openwrt.cc) 下载 OpenWrt 固件；
    3. 进入 OpBoot，上传 ubi 固件以全新安装 OpenWrt；
    4. 如果设备已安装 OpenWrt，可在 「LuCI - 系统 - 备份/升级 - 刷写新的固件」 菜单中将现有 OpenWrt 升级为本项目 OpenWrt，升级前请去掉 「保留配置」 的勾选。

### X86 设备

(由于兼容性问题，本项目 x86 固件建议使用以下指定的刷入工具安装固件)

!!! info ""
    1. 从 [软件源站](https://openwrt.cc/restore/Restore-SDCard-2G.img.zip) 下载 OpenWrt 固件；
    2. 制作 PE 启动 U 盘，并将 OpenWrt 固件复制到 U 盘合适位置；
    3. 下载刷入工具 [DiskImg-v1.2.exe](https://openwrt.cc/tools/DiskImg-v1.2.exe)，并将刷入工具复制到 U 盘合适位置；
    4. 将 U 盘插入设备，启动 PE 系统并使用刷入工具 (DiskImg-v1.2.exe) 将本项目 OpenWrt 固件刷入设备。

## 升级

无需解压 gz 文件，在 「LuCI - 系统 - 备份/升级 - 刷写新的固件」 中上传 sysupgrade 固件的 gz 压缩包即可进行升级操作；

如果升级失败，也可在 「LuCI - 系统 - 备份/升级 - 备份/恢复」 中点击 「生成备份」 下载当前配置文件的 tar 存档，按上文方式全新安装固件后在 「LuCI - 系统 - 备份/升级 - 备份/恢复」中上传此 tar 存档即可恢复之前固件的设置。

