# 空间扩容

!!! tip ""
    本文档适用范围：[OpenWrt-Rpi](/2-OpenWrt-Rpi)、[OpenWrt-Buildbot](/3-OpenWrt-Buildbot)

本节所述内容适用于以 SD 卡或硬盘为存储介质的设备，如树莓派、NanoPi R2S、X86 设备等。

将本项目 OpenWrt 固件刷入 SD 卡后，SD 卡内 boot 分区所占空间为 64M，root 分区所占空间为 960M，所以: 

SD 卡总容量 - (64+960)M ≈ 空闲分区容量

虽然刷入固件的初始状态下空闲分区无法被利用，但在默认情况下，960M 的 root 分区完全能胜任日常使用。

若确有扩容 root 分区的需求，请按下文内容操作。

!!! danger "小心"
    数据无价，在扩容操作前，请务必备份好 SD 卡内的重要数据。

!!! warning "注意"
    如确有扩容需求，请尽量在全新刷入固件后立即进行分区扩容操作，在全新刷入状态后进行扩容操作不仅可以避免文件丢失，在一定程度上还可加快分区扩容速度。

## ext4 固件

由于未知原因，ext4 固件暂时无法在 Windows 下使用 Diskgenius、PartitionGuru 等磁盘管理工具扩容，所以我们需要在 Linux 环境下对 SD 卡进行扩容操作。

:one: 如果你有现成的 Linux 环境，则可以将 SD 卡插入电脑，使用 GParted 工具对 SD 卡的 Root 分区进行扩容；

:two: 如果你有空闲的 U 盘，则可以将 Linux 发行版的 Live CD 写入 U 盘，重启至 U 盘中的 Live 环境使用 GParted 工具对 SD 卡进行扩容；

:three: 如果以上条件都不满足，则可使用虚拟机软件虚拟 Gparted 的 Live CD，在虚拟机中完成 SD 卡的扩容。

以下内容介绍 (相对最麻烦的) 方法 :three: ，方法 :one: 和 :two: 与方法 :three: 大同小异，在此不再赘述。

在接下来的内容中，我们使用开源免费的 VirtualBox 来进行 SD 卡的扩容操作，VMWare 下的操作步骤与 VirtualBox 相似，在此也不再赘述。

### 下载所需文件

**(点击各彩色条目即可展开该步骤对应图片)**

前往 VirtualBox 官网的下载页面:

<https://www.virtualbox.org/wiki/Downloads>

??? info "下载适用于 Windows 的 VirtualBox 安装包和扩展包:"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_893d5bfd6c402fefba3b02063a323f96.png)


文件下载到本地后，注意比对文件名中的版本号是否一致。以上图为例，安装包和扩展包的文件名分别为:

VirtualBox-6.1.16-140961-Win.exe

Oracle_VM_VirtualBox_Extension_Pack-6.1.16.vbox-extpack

两文件名中版本号 (6.1.16) 相同，则证明文件下载正确。

接着，我们前往 Gparted 官网的下载页面:

<https://gparted.org/download.php>

??? info "下载适用于 x86_64 设备的 Live CD 映像»"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_08bf1cf10c82b4d0c38e82914d6ab236.png)

至此，扩容所需文件下载完成。

### 建立虚拟 GParted Live 环境

**(点击各彩色条目即可展开该步骤对应图片)**

在 VirtualBox 安装过程中，除安装目录外，不建议对其他选项进行修改操作。

完成 VirtualBox 的安装后，双击刚刚下载好的扩展包，完成对 VirtualBox 扩展包的安装。

接下来的步骤在 VirtualBox 中进行:

??? example "1. 虚拟机类型选择为“Linux”，版本选择为“Other Linux (64-bit)” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_a653d16f15eef48e8574722ad361206b.png)

??? example "2. 内存分配默认的 512M 即可 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_c215ea20b509173bf0d73aef413c4b19.png)

??? example "3. 因为我们将在虚拟机中运行 Live 映像，所以不必配置虚拟磁盘 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_b55f622dc7b0be66c8776b06598ea100.png)

??? example "4. 选中刚刚创建好的虚拟机，点击“设置”按钮进入详细的虚拟机配置界面 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_b17214364b37eaeac102d7e2f8b5559f.png)

??? example "5. 在“系统 - 启动项”中，将“光驱”设为唯一启动项并将其移动到第一位 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_11aa3fb53c90a416ab22a84b34815393.png)

??? example "6. 注册并应用我们刚刚下载好的 GParted Live CD 文件 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_6fb685a5647583c4bdbf131ddfd24880.png)
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_a8668b709c62a24ef23dba2b3c1c0757.png)
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_a8ffbac7bae70a2c36b1ca8eda8d7002.png)
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_1ea6cab5a70ea1c3fc3cac3bbe8fde46.png)

??? example "7. 将 SD 卡装入读卡器插入电脑，在“USB 设备”中，勾选 USB 2.0 选项，点击右侧按钮将 USB 读卡器设备分配给虚拟机 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_6b8a4979587c68bf097a8337675462fa.png)

??? example "8. 回到主界面，启动虚拟机 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_59ec3014a84ec1e67c5d3d38ddcddc4c.png)

??? example "9. 在启动菜单中选择 (默认的) 第一个选项，按下回车键进入 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_2f56c526477b586996e1de06a7454f2b.png)

??? example "10. 默认情况下不需要选择按键布局，故我们直接按下回车键选择默认选项进入 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_82d18803cfc833795b241f1f9bca22e6.png)

??? example "11. 输入 “26” 将界面语言选择为“简体中文” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_e722e50636b77f7f4e5d89fa05b38d61.png)

??? example "12. 输入“0”并回车直接进入 X 界面 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_e5b69eb30552fef18ea0071ebef3642f.png)

??? example "13. 进入图形界面后，将自动启动 Gparted »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_2313b32705a83295bcdf642f0188e84f.png)

??? example "14. 右击卷标为“rootfs”的 960M 分区，选择“更改大小/移动” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_98cdf32c348239c742a49e3c01e0c559.png)

??? example "15. 拖动手柄调整 rootfs 大小进行扩容，如果你要进行全盘扩容操作，建议在 rootfs 分区前后留出大于 4M 的空间 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_651b4cae9ebabcb295944f04a00dd69a.png)

??? example "16. 回到 Gparted 主界面，点击“绿色箭头”执行扩容操作 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_85184da285337cf0982762df793f869a.png)

??? example "17. 扩容中...可能需要 1 分钟或几分钟 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_b120164f332056ec94dd24fe359bb774.png)

??? example "18. 扩容完成 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_8cb39b675450336df7fbcb04fc7fa7d5.png)

??? example "19. 回到主界面查看分区信息，确认分区扩容完毕 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_f41b3bc87601590aeb91f3b46113419f.png)

??? example "20. 回到桌面，依次点击“Exit - Shutdown”关机 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_e7e32b8480176f44adebc86ba509d8ec.png)


## Squashfs 固件

**(点击各彩色条目即可展开该步骤对应图片)**

对于 squashfs 固件，我们可以在暂未使用的空闲空间上新建一个分区，之后将 overlay 分区中的内容拷贝到这个分区，然后将系统在 overlay 分区的挂载点修改为刚刚新建的分区来进行扩容。

!!! warning "注意"
    由于 Squashfs 固件的扩容操作涉及到文件迁移，所以请尽量在刷入固件后即进行分区扩容操作。

??? example "1. 在“系统 - 软件包”中查看 rootfs 剩余空间为 600M »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_af6fadc09d14f44d1c6aa225d6a9faf0.png)

??? example "2. 在“系统 - 磁盘管理”中找到 SD 卡设备 (/dev/mmcblk0)，点击“修改” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_9987a1e1ae27da4ec5a1f2db089588a8.png)
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_7c0e2478533253625193fadd8b712f4e.png)

??? example "3. 在分区信息中可以看出 SD 卡中有 14.83G 的空闲空间，点击右侧“新建”按钮新建分区 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_89410ce20b9506631d495f576be5c0fe.png)

??? example "4. 分区新建完成，点击“格式化” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_67e0940af1a0a2fea73c926b0b2c7105.png)

??? example "5. 选择 ext4 分区作为新分区的文件系统 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_ecd8d0176ff006edb47542853a987782.png)

??? example "6. 分区已成功格式化为 ext4 格式 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_96307f775f89feca6a7017743556ee90.png)

??? example "7. 进入 OpenWrt 的 TTYD 或 SSH，进行迁移文件操作 »"

    ```
    # 将刚刚新建的 /dev/mmcblk0p3 分区挂载至 /mnt
    root@OpenWrt:/# mount /dev/mmcblk0p3 /mnt
        
    # 查看分区挂载情况
    root@OpenWrt:/# lsblk
    NAME        MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
    loop0         7:0    0 760.8M  0 loop /overlay
    mmcblk0     179:0    0  14.9G  0 disk 
    ├─mmcblk0p1 179:1    0    64M  0 part /boot
    ├─mmcblk0p2 179:2    0   960M  0 part /rom
    └─mmcblk0p3 179:3    0  13.8G  0 part /mnt

    # 将 /overlay 分区下的所有文件拷贝至刚刚建立好的分区内
    root@OpenWrt:/# cp -f -a /overlay/. /mnt

    # 查看是否拷贝成功
    root@OpenWrt:/# ls -a /mnt
    .           ..          .fs_state   lost+found  upper       work
    root@OpenWrt:/# ls -a /overlay
    .          ..         .fs_state  upper      work

    # 同步文件
    root@OpenWrt:/# sync

    # 卸载 /dev/mmcblk0p3 分区
    root@OpenWrt:/# umount /mnt
    ```

??? example "8. 前往“系统 - 挂载点”，点击“生成配置” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_40fc2abbb3891e08a1b2ca7632a1548c.png)


??? example "9. 在“挂载点”中我们可以看到刚刚创建好的 ext4 分区 /dev/mmcblk0p3，点击右方“修改” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_3fc3b674c808e3ead9ccc92c5043f4ac.png)


??? example "10. 在接下来的界面中，“启用此挂载点”并选择“作为外部 overlay 使用”，点击“保存&应用” »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_f24dd68d75cd33d48cee4415f8a2b7a3.png)


??? example "11. 在“系统 - 挂载点”页面下，确认挂载点已启用 (打钩)，并确认挂载点为 /overlay，点击下方“保存&应用”，之后重启 OpenWrt »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_4f3defdeb0f75e24656c9a94483ff2f6.png)


??? example "12. 验证分区扩容成功 »"
    ![](https://shop.io.mi-img.com/app/shop/img?id=shop_d66bddd2e933d84d6eb67c8ca5033a9a.png)
    ```
    root@OpenWrt:/# lsblk
    NAME        MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
    loop0         7:0    0 760.8M  0 loop /mnt/loop0
    mmcblk0     179:0    0  14.9G  0 disk 
    ├─mmcblk0p1 179:1    0    64M  0 part /boot
    ├─mmcblk0p2 179:2    0   960M  0 part /rom
    └─mmcblk0p3 179:3    0  13.8G  0 part /overlay

    root@OpenWrt:/# mount | grep overlay
    /dev/mmcblk0p3 on /overlay type ext4 (rw,relatime)
    overlayfs:/overlay on / type overlay (rw,noatime,lowerdir=/,upperdir=/overlay/upper,workdir=/overlay/work)
    overlayfs:/overlay on /opt/docker type overlay (rw,noatime,lowerdir=/,upperdir=/overlay/upper,workdir=/overlay/work)

    root@OpenWrt:/# df -h | grep overlay
    /dev/mmcblk0p3           13.5G     42.2M     12.8G   0% /overlay
    overlayfs:/overlay       13.5G     42.2M     12.8G   0% /
    overlayfs:/overlay       13.5G     42.2M     12.8G   0% /opt/docker
    ```
