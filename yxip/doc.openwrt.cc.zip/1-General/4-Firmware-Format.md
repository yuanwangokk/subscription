# 文件格式手册

!!! tip ""
    本文档适用范围：[OpenWrt-Rpi](/2-OpenWrt-Rpi)、[OpenWrt-Buildbot](/3-OpenWrt-Buildbot)

OpenWrt 固件的命名规则为:

项目名称 - 平台名称 - 子平台名称 - 设备名称 - 固件文件系统格式 - 固件类型&nbsp;.&nbsp;文件后缀

例如:

:file_folder: immortalwrt-bcm27xx-bcm2710-rpi-3-ext4-factory.img.gz

各部分解释如下:

!!! info ""
    1. 项目名称: immortalwrt (由固件源码定义)

    2. 平台名称: bcm27xx (博通 bcm27xx 平台)
    
    3. 子平台名称: bcm2710 (bcm2710 为 bcm27xx 下的子平台)
    
    4. 设备名称: rpi-3 (树莓派 3B)
    
    5. 固件文件系统格式: ext4 (ext4 文件系统)
    
    6. 固件类型: factory (工厂固件)
    
    7. 文件后缀: img.gz (经过 gzip 压缩后的 raw 固件)

## ext4 格式

例如：

:file_folder: immortalwrt-bcm27xx-bcm2711-rpi-4-**ext4**-factory.img.gz

ext4 格式的固件更适合熟悉 Linux 系统的用户使用，在 Linux 下可以比较方便地调整 ext4 分区的大小。

## squashfs 格式

例如：

:file_folder: immortalwrt-bcm27xx-bcm2711-rpi-4-**squashfs**-factory.img.gz

squashfs 固件的 rootfs 分区以高度压缩的方式存在，对于存储容量小的设备来说是个不错的选择。

启动系统时内核先以只读方式挂载原始 rootfs 分区，接着在 rootfs 分区之上挂载一个 overlay 分区并这两个分区合并，最终对外体现为一个可读写的 rootfs 分区。

对于原始 rootfs 分区的所有修改 (包括文件的添加和删除) 都在 overlay 分区中进行，这也意味着如果清除 overlay 分区的所有内容，OpenWrt 系统将对外体现为全新刷入固件时的状态。OpenWrt 的系统还原就利用了这样的特性，如果你一不小心玩坏固件，只要还能进入 LuCI 或 SSH，就可以很方便地进行 “系统还原操作”。

## factory 类型

例如：

:file_folder: immortalwrt-ipq40xx-generic-p2w_r619ac-squashfs-nand-**factory**.ubi

文件名中含有 factory 字样的固件字面意义为“工厂固件”，刷入此固件后设备中的无关数据将被清空，即可以用来“还原设备指出厂 (原始) 状态”的固件，

## sysupgrade 类型

例如：

:file_folder: immortalwrt-ipq40xx-generic-p2w_r619ac-squashfs-nand-**sysupgrade**.bin

文件名中含有 sysupgrade 字样的固件字面意义为“系统升级固件”，即可以用来进行设备升级的固件，广泛用于各平台设备，此固件可以在 OpenWrt 的 LuCI 面板或使用 sysupgrade 命令来升级原 OpenWrt 固件为新版本，用户可以自行决定他们的数据何去何从 (清除或保留)。

注意：有些设备并不提供 factory 固件，如果你在文件列表中找不到 factory 固件，那么此设备的 sysupgrade 固件也可代替 factory 固件来使用。例如:

:file_folder: immortalwrt-rockchip-armv8-friendlyarm_nanopi-r2s-ext4-**sysupgrade**.img.gz