# 文件名索引

!!! tip ""
    本文档适用范围：[OpenWrt-Rpi](/2-OpenWrt-Rpi)、[OpenWrt-Buildbot](/3-OpenWrt-Buildbot)

## 树莓派

**以树莓派 4 为例:**

| 文件名称                                                     | 描述                                |
| ------------------------------------------------------------ | ----------------------------------- |
| config.buildinfo                                             | 编译配置文件                        |
| feeds.buildinfo                                              | Feeds 仓库信息                      |
| immortalwrt-bcm27xx-bcm2711-rootfs.tar.gz                    | bcm27xx/bcm2711 平台 RootFS 文件    |
| immortalwrt-bcm27xx-bcm2711-rpi-4-ext4-factory.img.gz        | 树莓派 4B Ext4 格式全新安装固件     |
| immortalwrt-bcm27xx-bcm2711-rpi-4-ext4-sysupgrade.img.gz     | 树莓派 4B Ext4 格式升级专用固件     |
| immortalwrt-bcm27xx-bcm2711-rpi-4-initramfs-kernel.bin       | 树莓派 4B RamFS 固件                |
| immortalwrt-bcm27xx-bcm2711-rpi-4-rootfs.tar.gz              | 树莓派 4B RootFS 文件               |
| immortalwrt-bcm27xx-bcm2711-rpi-4-squashfs-factory.img.gz    | 树莓派 4B Squashfs 格式全新安装固件 |
| immortalwrt-bcm27xx-bcm2711-rpi-4-squashfs-sysupgrade.img.gz | 树莓派 4B Squashfs 格式升级专用固件 |
| immortalwrt-bcm27xx-bcm2711-rpi-4.manifest                   | 树莓派 4B 固件内已集成的软件包列表  |
| immortalwrt-bcm27xx-bcm2711.manifest                         | bcm27xx/bcm2711 平台固件软件包列表  |
| immortalwrt-imagebuilder-bcm27xx-bcm2711.Linux-x86_64.tar.xz | bcm27xx/bcm2711 平台 Image Builder  |
| immortalwrt-sdk-bcm27xx-bcm2711_gcc-8.4.0_musl.Linux-x86_64.tar.xz | bcm27xx/bcm2711 平台 SDK            |
| immortalwrt-toolchain-bcm27xx-bcm2711_gcc-8.4.0_musl.Linux-x86_64.tar.bz2 | bcm27xx/bcm2711 平台工具链          |
| profiles.json                                                | json 格式的固件信息                 |
| sha256sums                                                   | 完整性校验文件                      |
| version.buildinfo                                            | 源码 / 固件版本信息                 |

## Rockchip 平台

**以 NanoPi R2S 为例:**

| 文件名称                                                     | 描述                               |
| ------------------------------------------------------------ | ---------------------------------- |
| config.buildinfo                                             | 编译配置文件                       |
| feeds.buildinfo                                              | Feeds 仓库信息                     |
| immortalwrt-imagebuilder-rockchip-armv8.Linux-x86_64.tar.xz  | rockchip/armv8 平台 ImageBuilder   |
| immortalwrt-rockchip-armv8-friendlyarm_nanopi-r2s-ext4-sysupgrade.img.gz | NanoPi R2S Ext4 格式固件           |
| immortalwrt-rockchip-armv8-friendlyarm_nanopi-r2s.manifest   | NanoPi R2S 固件内已集成软件包列表  |
| immortalwrt-rockchip-armv8-friendlyarm_nanopi-r2s-rootfs.tar.gz | NanoPi R2S RootFS 文件             |
| immortalwrt-rockchip-armv8-friendlyarm_nanopi-r2s-squashfs-sysupgrade.img.gz | NanoPi R2S Squashfs 格式固件       |
| immortalwrt-rockchip-armv8.manifest                          | rockchip/armv8 平台软件包列表      |
| immortalwrt-rockchip-armv8-rootfs.tar.gz                     | rockchip/armv8 平台 RootFS 文件    |
| immortalwrt-sdk-rockchip-armv8_gcc-8.4.0_musl.Linux-x86_64.tar.xz | rockchip/armv8 平台 OpenWrt SDK    |
| immortalwrt-toolchain-rockchip-armv8_gcc-8.4.0_musl.Linux-x86_64.tar.bz2 | rockchip/armv8 平台 OpenWrt 工具链 |
| profiles.json                                                | json 格式的固件信息                |
| sha256sums                                                   | 完整性校验文件                     |
| version.buildinfo                                            | 源码 / 固件版本信息                |

## IPQ40xx 平台

**以竞斗云为例:**

| 文件名称                                                     | 描述                              |
| ------------------------------------------------------------ | --------------------------------- |
| config.buildinfo                                             | 编译配置文件                      |
| feeds.buildinfo                                              | Feeds 仓库信息                    |
| immortalwrt-imagebuilder-ipq40xx-generic.Linux-x86_64.tar.xz | ipq40xx/generic 平台 ImageBuilder |
| immortalwrt-ipq40xx-generic-p2w_r619ac-128m.manifest         | 竞斗云固件内已集成软件包列表      |
| immortalwrt-ipq40xx-generic-p2w_r619ac-128m-initramfs-fit-zImage.itb | 竞斗云 FIT 镜像文件               |
| immortalwrt-ipq40xx-generic-p2w_r619ac-128m-rootfs.tar.gz    | 竞斗云 RootFS 文件                |
| immortalwrt-ipq40xx-generic-p2w_r619ac-128m-squashfs-nand-factory.ubi | 竞斗云 Squashfs 格式 UBI 镜像文件 |
| immortalwrt-ipq40xx-generic-p2w_r619ac-128m-squashfs-nand-sysupgrade.bin | 竞斗云 Squashfs 格式升级专用文件  |
| immortalwrt-ipq40xx-generic-rootfs.tar.gz                    | ipq40xx/generic 平台 RootFS 文件  |
| immortalwrt-ipq40xx-generic.manifest                         | ipq40xx/generic 平台软件包列表    |
| immortalwrt-sdk-ipq40xx-generic_gcc-8.4.0_musl_eabi.Linux-x86_64.tar.xz | ipq40xx/generic 平台 SDK          |
| immortalwrt-toolchain-ipq40xx-generic_gcc-8.4.0_musl_eabi.Linux-x86_64.tar.bz2 | ipq40xx/generic 平台工具链        |
| profiles.json                                                | json 格式的固件信息               |
| sha256sums                                                   | 固件完整性校验文件                |
| version.buildinfo                                            | 源码 / 固件版本信息               |

## x86 平台

**以 x86_64 设备为例:**

| 文件名称                                                     | 描述                                                 |
| ------------------------------------------------------------ | ---------------------------------------------------- |
| config.buildinfo                                             | 编译配置文件                                         |
| feeds.buildinfo                                              | Feeds 仓库信息                                       |
| immortalwrt-imagebuilder-x86-64.Linux-x86_64.tar.xz          | x86/64 平台 ImageBuilder                             |
| immortalwrt-sdk-x86-64_gcc-8.4.0_musl.Linux-x86_64.tar.xz    | x86/64 平台 SDK                                      |
| immortalwrt-toolchain-x86-64_gcc-8.4.0_musl.Linux-x86_64.tar.xz | x86/64 平台工具链                                    |
| immortalwrt-x86-64-generic-ext4-combined-efi.img.gz          | x86/64 设备 EFI 平台 ext4 格式固件                   |
| immortalwrt-x86-64-generic-ext4-combined-efi.qcow2.gz        | x86/64 设备 EFI 平台 ext4 格式 kvm 固件              |
| immortalwrt-x86-64-generic-ext4-combined-efi.vdi.gz          | x86/64 设备 EFI 平台 ext4 格式 vdi 虚拟磁盘固件      |
| immortalwrt-x86-64-generic-ext4-combined-efi.vhdx.gz         | x86/64 设备 EFI 平台 ext4 格式 vhdx 虚拟磁盘固件     |
| immortalwrt-x86-64-generic-ext4-combined-efi.vmdk.gz         | x86/64 设备 EFI 平台 ext4 格式 vmdk 虚拟磁盘固件     |
| immortalwrt-x86-64-generic-ext4-combined.img.gz              | x86/64 设备传统平台 ext4 格式 固件                   |
| immortalwrt-x86-64-generic-ext4-combined.qcow2.gz            | x86/64 设备传统平台 ext4 格式 kvm 固件               |
| immortalwrt-x86-64-generic-ext4-combined.vdi.gz              | x86/64 设备传统平台 ext4 格式 vdi 虚拟磁盘固件       |
| immortalwrt-x86-64-generic-ext4-combined.vhdx.gz             | x86/64 设备传统平台 ext4 格式 vhdx 虚拟磁盘固件      |
| immortalwrt-x86-64-generic-ext4-combined.vmdk.gz             | x86/64 设备传统平台 ext4 格式 vmdk 虚拟磁盘固件      |
| immortalwrt-x86-64-generic-ext4-rootfs.img.gz                | x86/64 平台 ext4 格式固件 (不带引导)                 |
| immortalwrt-x86-64-generic-image-efi.iso                     | x86/64 设备 EFI 平台 iso 光盘映像                    |
| immortalwrt-x86-64-generic-image.iso                         | x86/64 设备传统平台 iso 光盘映像                     |
| immortalwrt-x86-64-generic-initramfs-kernel.bin              | x86/64 设备 RamFS 固件                               |
| immortalwrt-x86-64-generic-kernel.bin                        | x86/64 设备内核文件                                  |
| immortalwrt-x86-64-generic-rootfs.tar.gz                     | x86/64 RootFS 归档文件                               |
| immortalwrt-x86-64-generic-squashfs-combined-efi.img.gz      | x86/64 设备 EFI 平台 squashfs 格式固件               |
| immortalwrt-x86-64-generic-squashfs-combined-efi.qcow2       | x86/64 设备 EFI 平台 squashfs 格式 kvm 固件          |
| immortalwrt-x86-64-generic-squashfs-combined-efi.vdi         | x86/64 设备 EFI 平台 squashfs 格式 vdi 虚拟磁盘固件  |
| immortalwrt-x86-64-generic-squashfs-combined-efi.vhdx        | x86/64 设备 EFI 平台 squashfs 格式 vhdx 虚拟磁盘固件 |
| immortalwrt-x86-64-generic-squashfs-combined-efi.vmdk        | x86/64 设备 EFI 平台 squashfs 格式 vmdk 虚拟磁盘固件 |
| immortalwrt-x86-64-generic-squashfs-combined.img.gz          | x86/64 设备传统平台 squashfs 格式固件                |
| immortalwrt-x86-64-generic-squashfs-combined.qcow2           | x86/64 设备传统平台 squashfs 格式 kvm 固件           |
| immortalwrt-x86-64-generic-squashfs-combined.vdi             | x86/64 设备传统平台 squashfs 格式 vdi 虚拟磁盘固件   |
| immortalwrt-x86-64-generic-squashfs-combined.vhdx            | x86/64 设备传统平台 squashfs 格式 vhdx 虚拟磁盘固件  |
| immortalwrt-x86-64-generic-squashfs-combined.vmdk            | x86/64 设备传统平台 squashfs 格式 vmdk 虚拟磁盘固件  |
| immortalwrt-x86-64-generic-squashfs-rootfs.img.gz            | x86/64 设备 squashfs 格式固件 (不带引导)             |
| immortalwrt-x86-64-generic.manifest                          | x86/64 设备软件包列表                                |
| immortalwrt-x86-64-rootfs.tar.gz                             | x86/64 平台 RootFS 归档文件                          |
| immortalwrt-x86-64.manifest                                  | x86/64 平台软件包列表                                |
| profiles.json                                                | json 格式的固件信息                                  |
| sha256sums                                                   | 固件完整性校验文件                                   |
| version.buildinfo                                            | 源码  / 固件版本信息                                 |