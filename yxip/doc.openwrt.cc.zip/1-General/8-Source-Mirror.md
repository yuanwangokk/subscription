# 源码包镜像

在 OpenWrt 编译每个软件包前，需要在网络中下载每个软件包的源码包缓存到本地，这些源码包大多存放于国外站点上。

由于众所周知的原因，即使在使用代理工具的情况下，OpenWrt 在下载这些软件包时也会花费大量时间。在网络不佳的情况下，OpenWrt Buildroot 常会因无法下载到 正确 / 完整 的软件包而导致编译抛出错误，大多数编译失败的原因就来源于此。

为了解决这个问题，我们在 OpenWrt.cc 下建立了热门的 OpenWrt 分支软件包镜像，本节就来介绍一下如何使用我们提供的 OpenWrt 源码包镜像。

## 简介

OpenWrt 源码包镜像的 Workflows 是 OpenWrt-Buildbot 项目的一部分：

[Workflows](https://github.com/SuLingGG/OpenWrt-Buildbot/blob/main/.github/workflows/update-dl.yml) | [Action](https://github.com/SuLingGG/OpenWrt-Buildbot/actions/workflows/update-dl.yml)

镜像更新频率为每日更新一次。

OpenWrt 源码包镜像提供 4 个项目对应的源码包镜像，每个镜像即可涵盖当前项目下的所有支持分支。

!!! warning ""
    在国内网络环境下，即使你正在使用我们提供的源码包镜像，编译 OpenWrt 时仍需开启代理。

    虽然我们提供了源码包镜像，但由于源码更新等原因，我们仍无法保证源码包镜像能 100% 覆盖到所有的软件包 (镜像更新频率为每日更新一次)。
    
    如果软件包在源内未能找到，OpenWrt Buildroot 将按原地址下载源码包 (而不会抛出错误)。

## 支持项目

OpenWrt 源码包镜像支持以下 项目 / 分支，各项目对应镜像地址可在下表「源码包镜像地址」列找到：

| 项目                                                         | 支持分支                                                     | 源码包镜像地址                                  |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ----------------------------------------------- |
| [openwrt/openwrt](https://github.com/openwrt/openwrt)        | [master](https://github.com/openwrt/openwrt/tree/master) / [openwrt-21.02](https://github.com/openwrt/openwrt/tree/openwrt-21.02) / [openwrt-19.07](https://github.com/openwrt/openwrt/tree/openwrt-19.07) / [openwrt-18.06](https://github.com/openwrt/openwrt/tree/openwrt-18.06) / [lede-17.01](https://github.com/openwrt/openwrt/tree/lede-17.01) | <https://openwrt.cc/dl/openwrt/openwrt>         |
| [coolsnowwolf/lede](https://github.com/coolsnowwolf/lede)    | [master](https://github.com/coolsnowwolf/lede/tree/master)   | <https://openwrt.cc/dl/coolsnowwolf/lede>       |
| [immortalwrt/immortalwrt](https://github.com/immortalwrt/immortalwrt) | [master](https://github.com/immortalwrt/immortalwrt/tree/master) / [openwrt-21.02](https://github.com/immortalwrt/immortalwrt/tree/openwrt-21.02) / [openwrt-18.06](https://github.com/immortalwrt/immortalwrt/tree/openwrt-18.06) / [openwrt-18.06-k5.4](https://github.com/immortalwrt/immortalwrt/tree/openwrt-18.06-k5.4) | <https://openwrt.cc/dl/immortalwrt/immortalwrt> |
| [Lienol/openwrt](https://github.com/Lienol/openwrt)          | [main](https://github.com/Lienol/openwrt) / [19.07](https://github.com/Lienol/openwrt/tree/19.07) / [21.02](https://github.com/Lienol/openwrt/tree/21.02) | <https://openwrt.cc/dl/lienol/openwrt>          |

## 使用方法

### 图形化方式

在 OpenWrt 源码目录下执行 `make menuconfig`，按上下光标键选择「Advanced configuration options (for developers)」，按下空格键启用开发者选项 (开头括号中将显示一个 [*] 符号)。

<img src="https://ae02.alicdn.com/kf/Hd3daf77678c443f9b5c6668afd4a11feU.png" alt="1.png" style="zoom:67%;" />

按下回车，进入开发者选项菜单，按上下光标键选择「Local mirror for source packages」:

<img src="https://ae01.alicdn.com/kf/H509fa7c175714835b3fb19124812453fd.png" alt="2.png" style="zoom:67%;" />

按下回车，进入镜像地址输入界面，在输入框输入源码对应的软件包镜像地址。

<https://openwrt.cc/dl/openwrt/openwrt>

!!! warning ""
    源码包镜像地址只与源码项目有关，和当前使用的分支无关。例如你正在使用 openwrt/openwrt 源码的 openwrt-18.06 分支编译 OpenWrt，你只需要填入上表中与当前项目对应的源码包镜像地址即可：

<img src="https://ae01.alicdn.com/kf/H137eb97924a340c59794563625dc083bz.png" alt="3.png" style="zoom:67%;" />

按 Tab 键将光标移动到 < ok > 处，按 回车键退出输入窗口，确认地址已输入正确。

<img src="https://ae05.alicdn.com/kf/H85865c40055f415f970a58f944abdf29f.png" alt="4.png" style="zoom:67%;" />

完成其余的 OpenWrt 配置后，保存配置：

<img src="https://ae02.alicdn.com/kf/H539f45a9c6244832abb9d0b832feb344v.png" alt="5.png" style="zoom:67%;" />

保存配置后使用 `make download` 命令下载软件包或者直接执行 `make` 命令编译即可。

### 命令行方式

我们也可以通过直接修改 .config 的方式来配置软件包镜像源。

在 OpenWrt 源码目录执行以下命令即可启用镜像源：

```
echo 'CONFIG_DEVEL=y\nCONFIG_LOCALMIRROR="https://openwrt.cc/dl/openwrt/openwrt"' >> .config

make defconfig
```

其中 `https://openwrt.cc/dl/openwrt/openwrt` 为你当前所用的 OpenWrt 源码对应的软件包镜像地址。

## 验证

我们执行 `make download -j1 V=s` 命令查看 OpenWrt Buildroot 是否正在通过我们指定的镜像下载软件包：

<img src="https://ae03.alicdn.com/kf/H886f28dae3204b67b84f20a7c9e1c09cI.png" alt="6.png" style="zoom:67%;" />
