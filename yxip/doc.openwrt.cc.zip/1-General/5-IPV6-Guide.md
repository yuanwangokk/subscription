# IPV6 指南

!!! tip ""
    本文档适用范围：[OpenWrt-Rpi](/2-OpenWrt-Rpi)、[OpenWrt-Buildbot](/3-OpenWrt-Buildbot)

!!! danger "注意"
    1. 如非必要，请不要启用 IPV6。

    2. 如果你确认要启用 IPV6，请确认你在社区和论坛中搜索和学习 OpenWrt IPV6 相关知识所用时间 > 2 小时。

    3. 如果你在启用 IPV6 的情况下遇到了一些奇奇怪怪的问题，请不要向我发送反馈。

## IPV6 模块

### 安装

为了避免一些问题 (CDN 绕路 / DNS 抢答)，OpenWrt-Rpi 与 OpenWrt-Buildbot 项目释出的固件均未添加 IPV6 支持。如果你想在这两个固件中使用 IPV6，可以尝试 `ipv6-helper` 脚本。

执行以下命令即可将`ipv6-helper` 脚本安装至固件：

``` shell
wget --no-check-certificate -O "/usr/bin/ipv6-helper" https://openwrt.cc/scripts/ipv6-helper.sh

chmod +x /usr/bin/ipv6-helper
```

在 OpenWrt 的 SSH 或 TTYD 中执行 `ipv6-helper` 命令可以得到工具的帮助信息：

```
~ # ipv6-helper

This script can help you install IPV6 modules on OpenWrt.

Usage:
ipv6-helper sub-command
Example:
        ipv6-helper install: Install ipv6-helper & IPV6 modules
        ipv6-helper remove: Remove ipv6-helper & IPV6 modules

Optional Usage:
        ipv6-helper server: Set IPV6 configuration to server mode
        ipv6-helper relay: Set IPV6 configuration to relay mode
        ipv6-helper hybrid: Set IPV6 configuration to hybrid mode
```

### 使用

`ipv6-helper install`: 安装 IPV6 模块并将 IPV6 配置为混合 (Hybrid) 模式 (默认)

`ipv6-helper remove`: 移除 IPV6 模块并回滚与 IPV6 相关的所有配置

`ipv6-helper server`: 将 IPV6 配置为服务器 (Server) 模式

`ipv6-helper relay`: 将 IPV6 配置为中继 (Relay) 模式

`ipv6-helper hybrid`: 将 IPV6 配置为混合 (Hybrid) 模式

## 注意事项

!!! warning ""
    1. 使用`ipv6-helper`脚本进行的安装 / 移除 / 配置 IPV6 操作均需要重启 OpenWrt，可在脚本中选择立即重启和稍后重启，按照实际情况重启即可。如果可能，建议在安装 / 移除 / 配置 IPV6 后重启局域网内的客户端设备 (对于群晖设备来说这点可能非常有用)。

    2. 执行 `ipv6-helper install` 完成 IPV6 模块的安装后，脚本将自动把 IPV6 配置为混合 (Hybrid) 模式。

    3. 如果在 OpenWrt 重启后混合 (Hybrid) 模式下的 IPV6 工作不正常，可以尝试执行 `ipv6-helper server` 将 IPV6 配置为服务器 (Server) 模式。或执行 `ipv6-helper relay` 将 IPV6 配置为中继 (Relay) 模式。

    4. 为了避免使用 IPV6 解析域名带来的一系列问题 (CDN 绕路 / DNS 抢答)，脚本在执行 IPV6 安装 / 移除的过程中均启用了 “禁止解析 IPv6 DNS 记录” 特性，启用此特性将“过滤掉 IPv6 (AAAA) ，只返回 IPv4 DNS 域名记录”，如果你想在 “IPV6-Test” 之类的网站中通过所有 IPV6 测试，或者你有通过 IPV6 解析 DNS 的需求，可以在「LuCI 面板 - 网络 - DHCP/DNS - 高级设置 - 禁止解析 IPv6 DNS 记录」中取消勾选这一选项。或者执行 `uci set dhcp.@dnsmasq[0].filter_aaaa=1` 亦可。
