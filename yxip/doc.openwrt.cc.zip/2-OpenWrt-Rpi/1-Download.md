# 固件下载

## 提示
!!! info ""
    1. 点击下表中「固件下载」列的 🔗 图标即可跳转至相应设备固件下载页
    2. 固件 IP、LuCI 界面 帐号/密码 等信息请移步「[初始设置](/1-General/2-Initialization)」
    3. 查看固件下载页面的固件类型信息请前往「[文件名索引](/1-General/3-File-Name)」
    4. 各固件格式区别请前往「[文件格式手册](/1-General/4-Firmware-Format)」
    5. 若固件下载速度不理想，请尝试使用代理下载

## 支持设备

|<img width=25/>支持设备<img width=25/>|<img width=25/>支持平台<img width=25/>|<img width=25/>编译结果页<img width=25/>|<img width=25/>固件下载<img width=25/>|
| :----------------: | :----------------------------------------------------------: | :-------------------------------------------------------: | :-------------------------------------------------------: |
|   树莓派 1B   |   bcm27xx/bcm2708   | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-rpi1-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/bcm27xx/bcm2708/) |
|               树莓派 2B                |            bcm27xx/bcm2709             | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-rpi2-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/bcm27xx/bcm2709/) |
| 树莓派 3B |            bcm27xx/bcm2710             | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-rpi3-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/bcm27xx/bcm2710/) |
| 树莓派 4B | bcm27xx/bcm2711 | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-rpi4-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/bcm27xx/bcm2711/) |
| ipq40xx 设备 | ipq40xx/generic | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-gdock-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/ipq40xx/generic/) |
|   rockchip 设备   |   rockchip/armv8   | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-rockchip-lean-openwrt.yml?query=is%3Asuccess) | [🔗](https://openwrt.cc/releases/targets/rockchip/armv8/)  |
|   x86_64 设备   |   x86/64    | [🔗](https://github.com/SuLingGG/OpenWrt-Rpi/actions/workflows/build-x86_64-lean-openwrt.yml?query=is%3Asuccess) |     [🔗](https://openwrt.cc/releases/targets/x86/64/)      |
    