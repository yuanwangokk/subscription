# 网卡支持

OpenWrt-Rpi 项目固件已内置一些外置网卡驱动支持。

## USB 网卡

推荐使用 AX88179 或 RTL8153 芯片的 USB 转以太网网卡。

例如绿联的 USB 网卡 (有 AX88179 和 RTL8153 两种规格)，或者微软 1663 USB 网卡 (RTL8153)。

## 无线网卡

### 推荐

推荐使用基于 MT7612U (300Mbps+867Mbps) 芯片的 USB 无线网卡设备。

例如基于 MT7612U 的网件 A6210，根据反馈华硕 AC55 亦可 (保险起见还是推荐网件 A6210)。

如果预算不足，也可以使用基于雷凌 RT3070 (150Mbps) 芯片的 USB 网卡。

对于树莓派 3/4、R2S/R2C/R4S 等 aarch64 设备，固件内置了一些 RTL 无线网卡驱动。

如果你正在使用基于 rtl8812au/rtl88x2bu (x表示通配符) 芯片的设备，可以尝试在保留 `kmod-rtlwifi`，`kmod-rtlwifi-usb`，`kmod-rtl8812au-ac`/`kmod-rtl88x2bu` (根据你的网卡芯片型号二选一) 的情况下移除其他 `kmod-rtl*` 驱动，重启后重新禁用/启用网卡再试。

某些网卡在插入 USB 接口后可能需要在 「LuCI - 网络 - 无线」中禁用再启用设备才可正常运行。

### 备注

对于所有 Linux 发行版，没有 “免驱” 这一说 (OpenWrt 也不例外)，所以号称 “免驱” 的设备不一定在 Linux 发行版中可用。

本项目不接受 “请求添加 xxx 网卡支持” 的建议 (适配驱动需要大量时间和精力，我自己的能力有限，无法胜任)

虽然搭载 MT7612U 芯片的无线网卡一般支持 2.4G + 5G 双频段，但 OpenWrt 仅支持单频段无线信号的发送和接收，不支持双频并发。

由于 OpenWrt 限制，即使是同一 USB 无线网卡，在开机状态下热插拔设备后在「LuCI - 网络 - 无线」中可能仍被识别为不同的无线设备，这会导致在「LuCI - 网络 - 无线」中出现多个无线网络设备的情况，如果需要删除无用的无线网络设备，可以手动编辑 `/etc/config/wireless` 文件，删除多余的无线设备条目。

虽然固件内置了 RT5370 (150Mbps)、RT5572 (300Mbps+600Mbps) 的驱动，但根据反馈，OpenWrt 对这两种芯片的支持目前不太好。

如果你正在使用 32 位的 arm 设备 (树莓派 1/2)，不建议安装 kmod-rtl* 无线网卡驱动 (可能会与其他驱动产生一些冲突)。

## 3G/4G 网卡

固件已按照 [OpenWrt Guide](https://openwrt.org/docs/guide-user/network/wan/wwan/start) 添加了 3G/4G USB 网卡驱动，现固件默认已支持 3G/UMTS，QMI，NCM，RNDIS 协议的 3G/4G USB 网卡，如果网卡插入后未被识别，你可能需要通过 usbmode 命令切换 USB 网卡至工作状态。

详情请参考 OpenWrt Guide:

[How to use 3g/UMTS USB Dongle for WAN connection](https://openwrt.org/docs/guide-user/network/wan/wwan/3gdongle)

[How to use LTE modem in QMI mode for WAN connection](https://openwrt.org/docs/guide-user/network/wan/wwan/ltedongle)

[How to use LTE modem in RNDIS mode for WAN connection](https://openwrt.org/docs/guide-user/network/wan/wwan/ethernetoverusb_rndis)

[How To Use LTE modem in NCM mode for WAN connection](https://openwrt.org/docs/guide-user/network/wan/wwan/ethernetoverusb_ncm)

同时固件也集成了 `modemmanager` 与 `luci-proto-modemmanager`，可按需使用。

## 手机网络共享

OpenWrt-Rpi 固件已集成手机网络共享的一些驱动 (将 OpenWrt 设备与手机通过 USB 线连接起来，OpenWrt 通过手机流量连接 Internet)，可以根据网上已有的一些教程使用，在此不再赘述。