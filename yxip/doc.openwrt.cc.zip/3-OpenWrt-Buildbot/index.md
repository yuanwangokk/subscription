# 项目介绍

!!! tip ""
    项目地址: <https://github.com/SuLingGG/OpenWrt-Buildbot>

!!! info ""
    1. 提供绝大多数源码支持的 arm/aarch64/x86 平台设备的 OpenWrt 固件
    2. 除设备默认定义软件包外，固件内未额外集成其他软件包，确保获得纯净体验
    3. 固件每日跟随源码更新自动编译，确保获得最新体验
    4. 软件源每 2 日更新一次，源内可安装软件包达 7000+ 个
    5. 提供各大 OpenWrt 项目 / 分支的源码包 (dl) 镜像
    6. 提供全格式固件 / 文件 (ext4/squashfs/ubi/initramfs/rootfs)
    7. 对于高级用户，提供完整的固件/软件包构建工具 (imagebuilder / sdk / toolchain)

!!! warning ""
    “General” 目录下包含许多有用的文档，这些文档同样适用于本项目固件，[前往查看 »](/1-General)

## 固件预览

### 主界面:

![主界面](https://ae02.alicdn.com/kf/Hdc79e29a959146c29a53a03742cce90cX.png)

### 内置功能:

![内置功能](https://ae05.alicdn.com/kf/Hc47719b39ac04438beb10143c8e99b8cx.png)
