# 固件下载

## 提示

!!! info ""
    1. 点击下表 “Target/Subtarget” 列中的链接即可跳转至固件下载页面
    2. 固件 IP、LuCI 界面 帐号/密码 等信息请移步「[初始设置](/1-General/2-Initialization)」
    3. 查看固件下载页面的固件类型信息请前往「[文件名索引](/1-General/3-File-Name)」
    4. 各固件格式区别请前往「[文件格式手册](/1-General/4-Firmware-Format)」
    5. 若固件下载速度不理想，请尝试使用代理下载

## 支持平台

| Target/Subtarget                                             | Platform                  | Target/Subtarget                                             | Platform                 |
| ------------------------------------------------------------ | ------------------------- | ------------------------------------------------------------ | ------------------------ |
| [armvirt/32](https://openwrt.cc/snapshots/targets/armvirt/32) | arm_cortex-a15_neon-vfpv4 | [mediatek/mt7629](https://openwrt.cc/snapshots/targets/mediatek/mt7629) | arm_cortex-a7            |
| [armvirt/64](https://openwrt.cc/snapshots/targets/armvirt/64) | aarch64_cortex-a53        | [mvebu/cortexa53](https://openwrt.cc/snapshots/targets/mvebu/cortexa53) | aarch64_cortex-a53       |
| [at91/sam9x](https://openwrt.cc/snapshots/targets/at91/sam9x) | arm_arm926ej-s            | [mvebu/cortexa72](https://openwrt.cc/snapshots/targets/mvebu/cortexa72) | aarch64_cortex-a72       |
| [at91/sama5](https://openwrt.cc/snapshots/targets/at91/sama5) | arm_cortex-a5_vfpv4       | [mvebu/cortexa9](https://openwrt.cc/snapshots/targets/mvebu/cortexa9) | arm_cortex-a9_vfpv3-d16  |
| [bcm27xx/bcm2708](https://openwrt.cc/snapshots/targets/bcm27xx/bcm2708) | arm_arm1176jzf-s_vfp      | [octeontx/generic](https://openwrt.cc/snapshots/targets/octeontx/generic) | aarch64_generic          |
| [bcm27xx/bcm2709](https://openwrt.cc/snapshots/targets/bcm27xx/bcm2709) | arm_cortex-a7_neon-vfpv4  | [omap/generic](https://openwrt.cc/snapshots/targets/omap/generic) | arm_cortex-a8_vfpv3      |
| [bcm27xx/bcm2710](https://openwrt.cc/snapshots/targets/bcm27xx/bcm2710) | aarch64_cortex-a53        | [oxnas/ox820](https://openwrt.cc/snapshots/targets/oxnas/ox820) | arm_mpcore               |
| [bcm27xx/bcm2711](https://openwrt.cc/snapshots/targets/bcm27xx/bcm2711) | aarch64_cortex-a72        | [rockchip/armv8](https://openwrt.cc/snapshots/targets/rockchip/armv8) | aarch64_generic          |
| [bcm4908/generic](https://openwrt.cc/snapshots/targets/bcm4908/generic) | aarch64_cortex-a53        | [sunxi/cortexa53](https://openwrt.cc/snapshots/targets/sunxi/cortexa53) | aarch64_cortex-a53       |
| [bcm53xx/generic](https://openwrt.cc/snapshots/targets/bcm53xx/generic) | arm_cortex-a9             | [sunxi/cortexa7](https://openwrt.cc/snapshots/targets/sunxi/cortexa7) | arm_cortex-a7_neon-vfpv4 |
| [gemini/generic](https://openwrt.cc/snapshots/targets/gemini/generic) | arm_fa526                 | [sunxi/cortexa8](https://openwrt.cc/snapshots/targets/sunxi/cortexa8) | arm_cortex-a8_vfpv3      |
| [ipq40xx/generic](https://openwrt.cc/snapshots/targets/ipq40xx/generic) | arm_cortex-a7_neon-vfpv4  | [tegra/generic](https://openwrt.cc/snapshots/targets/tegra/generic) | arm_cortex-a9_vfpv3-d16  |
| [ipq806x/generic](https://openwrt.cc/snapshots/targets/ipq806x/generic) | arm_cortex-a15_neon-vfpv4 | [x86/64](https://openwrt.cc/snapshots/targets/x86/64)        | x86_64                   |
| [kirkwood/generic](https://openwrt.cc/snapshots/targets/kirkwood/generic) | arm_xscale                | [x86/generic](https://openwrt.cc/snapshots/targets/x86/generic) | i386_pentium4            |
| [layerscape/armv7](https://openwrt.cc/snapshots/targets/layerscape/armv7) | arm_cortex-a7_neon-vfpv4  |                                                              |                          |
